# ECS_EJ_01_Assets
Ejemplos de archivos de configuración que serán usados para el ejercicio de la semana 01
